document.addEventListener("DOMContentLoaded", function () {
    // Open cart.html, wishlist.html, or show orders
    document.getElementById("cart-link")?.addEventListener("click", function (e) {
        e.preventDefault();

        const user = localStorage.getItem("user");
        if (!user) {
            alert("Please sign in to view your wishlist.");
            return;
        }
        
        window.location.href = "cart.html";
    });

    document.getElementById("wishlist-link")?.addEventListener("click", function (e) {
        e.preventDefault();

        const user = localStorage.getItem("user");
        if (!user) {
            alert("Please sign in to view your wishlist.");
            return;
        }

        window.location.href = "wishlist.html";
    });

    document.getElementById("my-orders-link")?.addEventListener("click", function (e) {
        e.preventDefault();

        const user = localStorage.getItem("user");
        if (!user) {
            alert("Please sign in to view your orders.");
            return;
        }

        window.location.href = "orders.html";
    });

    // Handle product selection for product links
    document.querySelectorAll(".dress-link,.saree-link,.watch-link,.shirt-link,.webpage-link").forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();

            const user = localStorage.getItem("user");
            if (!user) {
                alert("Please sign in to perform this action.");
                return;
            }

            const productName = this.getAttribute("data-name");
            const productPrice = this.getAttribute("data-price");
            const productDescription = this.getAttribute("data-description");
            const productSizes = this.getAttribute("data-sizes") || "M,L,XL";
            const productImage = this.getAttribute("data-image");

            localStorage.setItem("productName", productName);
            localStorage.setItem("productPrice", productPrice);
            localStorage.setItem("productDescription", productDescription);
            localStorage.setItem("productSizes", productSizes);
            localStorage.setItem("productImage", productImage);

            window.location.href = "payment.html";
        });
    });

    // On payment.html
    if (window.location.pathname.includes("payment.html")) {
        const user = localStorage.getItem("user");
        if (!user) {
            alert("You must be signed in to access the payment page.");
            window.location.href = "webpage.html";
            return;
        }

        document.getElementById("product-name").innerHTML = localStorage.getItem("productName");
        document.getElementById("product-price").textContent = localStorage.getItem("productPrice");
        document.getElementById("product-description").innerHTML = localStorage.getItem("productDescription");
        document.getElementById("product-image").src = localStorage.getItem("productImage");

        const sizes = localStorage.getItem("productSizes").split(",");
        const sizeDropdown = document.getElementById("product-sizes");
        sizeDropdown.innerHTML = sizes.map(size => `<option value="${size.trim()}">${size.trim()}</option>`).join("");

        document.getElementById("buy-now").addEventListener("click", function () {
            window.location.href = "buynow.html";
        });

        document.getElementById("save-watchlist").addEventListener("click", function () {
            const wishlist = JSON.parse(localStorage.getItem("wishlist") || "[]");
            wishlist.push({
                name: localStorage.getItem("productName"),
                price: localStorage.getItem("productPrice"),
                image: localStorage.getItem("productImage")
            });
            localStorage.setItem("wishlist", JSON.stringify(wishlist));
            alert("Your product is saved to Wishlist!");
        });

        document.getElementById("add-to-cart").addEventListener("click", function () {
            const cart = JSON.parse(localStorage.getItem("cart") || "[]");
            cart.push({
                name: localStorage.getItem("productName"),
                price: localStorage.getItem("productPrice"),
                image: localStorage.getItem("productImage")
            });
            localStorage.setItem("cart", JSON.stringify(cart));
            alert("Your product is added to Cart! You can Buy Now.");
        });
    }

    // On buynow.html
    if (window.location.pathname.includes("buynow.html")) {
        const user = localStorage.getItem("user");
        if (!user) {
            alert("You must be signed in to place orders.");
            window.location.href = "webpage.html";
            return;
        }

        document.getElementById("product-name").textContent = localStorage.getItem("productName");
        document.getElementById("product-price").textContent = localStorage.getItem("productPrice");

        document.getElementById("submit-order").addEventListener("click", function () {
            const address = document.getElementById("address").value;
            if (!address) {
                alert("Please enter a valid delivery address.");
                return;
            }

            const paymentMethod = document.querySelector('input[name="payment"]:checked');
            if (!paymentMethod) {
                alert("Please select a payment method.");
                return;
            }

            const order = {
                name: localStorage.getItem("productName"),
                price: localStorage.getItem("productPrice"),
                image: localStorage.getItem("productImage"),
                address: address,
                payment: paymentMethod.value,
                time: new Date().toLocaleString()
            };

            const orders = JSON.parse(localStorage.getItem("orders") || "[]");
            orders.push(order);
            localStorage.setItem("orders", JSON.stringify(orders));
            localStorage.setItem("deliveryAddress", address);
            localStorage.setItem("paymentMethod", paymentMethod.value);


            if (paymentMethod.value === "upi") {
                let upi;
                while (true) {
                    upi = prompt("Enter your UPI ID:");
                    if (upi === null) {
                        alert("Order canceled.");
                        return;
                    }

                    const upiPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+$/;
                    if (!upiPattern.test(upi)) {
                        alert("Invalid UPI ID! Please enter a valid UPI ID.");
                    } else {
                        alert("Payment successful! Your order is placed.");
                        window.location.href = "tracking.html";
                        break;
                    }
                }
            } else {
                alert("Order placed successfully! You can track your delivery.");
                window.location.href = "tracking.html";
            }
        });

        document.getElementById("cancel-order").addEventListener("click", function () {
            alert("Order canceled.");
            window.location.href = "payment.html";
        });
    }
});