document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login_form");
    const signupForm = document.getElementById("signup_form");
    const forgotPasswordForm = document.getElementById("forgot-password-form");
    
    const loginSection = document.getElementById("login-form");
    const signupSection = document.getElementById("signup-form");
    const forgotPasswordSection = document.getElementById("forgot-password-form");
    const ecommerceSection = document.getElementById("ecommerce-page");

    const showSignup = document.getElementById("show-signup");
    const showLogin = document.getElementById("show-login");
    const forgotPasswordLink = document.getElementById("forgot-password");
    const backToLogin = document.getElementById("back-to-login");

    const userInfoUsername = document.getElementById("user-info-username");
    const userInfoEmail = document.getElementById("user-info-email");

    const logoutButton = document.getElementById("logout-button");

    // Show/Hide Forms
    showSignup.addEventListener("click", function () {
        loginSection.style.display = "none";
        signupSection.style.display = "block";
    });

    showLogin.addEventListener("click", function () {
        signupSection.style.display = "none";
        loginSection.style.display = "block";
    });

    forgotPasswordLink.addEventListener("click", function () {
        loginSection.style.display = "none";
        forgotPasswordSection.style.display = "block";
    });

    backToLogin.addEventListener("click", function () {
        forgotPasswordSection.style.display = "none";
        loginSection.style.display = "block";
    });

    // Login
    loginForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const username = document.getElementById("login-username").value;
        const password = document.getElementById("login-password").value;

        const response = await fetch("http://127.0.0.1:7000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
            alert("Logged in successfully!");
            loginSection.style.display = "none";
            ecommerceSection.style.display = "block";
            userInfoUsername.textContent = data.user.username;
            userInfoEmail.textContent = data.user.email;
            localStorage.setItem("user", JSON.stringify(data.user));
        } else {
            alert(data.message);
        }
    });

    // Signup
    signupForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const username = document.getElementById("signup-username").value;
        const email = document.getElementById("signup-email").value;
        const password = document.getElementById("signup-password").value;
        const confirmPassword = document.getElementById("signup-confirm-password").value;

        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        const response = await fetch("http://127.0.0.1:7000/signup", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, email, password })
        });

        const data = await response.json();
        alert(data.message);
        if (data.success) {
            signupSection.style.display = "none";
            loginSection.style.display = "block";
        }
    });

    // Forgot Password
    forgotPasswordForm.addEventListener("submit", async function (e) {
        e.preventDefault();
        const email = document.getElementById("forgot-email").value;

        const response = await fetch("http://127.0.0.1:7000/forgot-password", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email })
        });

        const data = await response.json();
        alert(data.message);
    });

    // Logout
    logoutButton.addEventListener("click", function () {
        localStorage.removeItem("user");
        ecommerceSection.style.display = "none";
        loginSection.style.display = "block";
    });

    // Maintain Session
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
        const user = JSON.parse(savedUser);
        loginSection.style.display = "none";
        ecommerceSection.style.display = "block";
        userInfoUsername.textContent = user.username;
        userInfoEmail.textContent = user.email;
    }
});
