require("dotenv").config();
const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "yourpassword",
    database: "eecommerce",
    port:3306
});

db.connect((err) => {
    if (err) {
        console.error("Database connection failed: " + err.message);
    } else {
        console.log("Connected to MySQL Database");
    }
});

// Save order details
app.post("/place-order", (req, res) => {
    console.log("🔵 Received raw request body:", req.body);

    const { productName, productPrice, productImage, deliveryAddress, paymentMethod } = req.body;

    console.log("🟢 Extracted Fields:", { productName, productPrice, productImage, deliveryAddress, paymentMethod });

    if (!productName || !productPrice || !productImage || !deliveryAddress || !paymentMethod) {
        console.log("❌ Missing fields:", { productName, productPrice, productImage, deliveryAddress, paymentMethod });
        return res.status(400).json({ error: "All fields are required." });
    }

    const sql = "INSERT INTO orders (product_name, product_price, product_image, delivery_address, payment_method) VALUES (?, ?, ?, ?, ?)";
    db.query(sql, [productName, productPrice, productImage, deliveryAddress, paymentMethod], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        res.json({ success: true, message: "✅ Order placed successfully!" });
    });
});

// Start Server
const PORT = process.env.PORT || 6000;
app.listen(PORT, () => console.log(`Server running on port ${6000}`));
